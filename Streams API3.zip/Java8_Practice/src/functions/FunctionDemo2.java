package functions;

import java.util.function.Function;

public class FunctionDemo2 {
    public static void main(String[] args) {
        Function<String,String> f1 = s->s.replace(" ","");
        System.out.println("My name is Mitali, after space removal: \n"+f1.apply("My name is Mitali"));

        Function<String,Integer> f2 = s->s.length()-s.replace(" ","").length();
        System.out.println("My name is Mitali, having spaces: "+f2.apply("My name is Mitali"));
    }
}
