package functions;

import java.util.function.Function;

public class FunctionDemo1 {
    public static void main(String[] args) {
        Function<String,Integer> f1 = s->s.length();
        System.out.println("Length of \"Mitali\" is :"+f1.apply("Mitali"));
        System.out.println("Length of \"Aggarwal\" is :"+f1.apply("Aggarwal"));

        Function<Integer,Integer> f2 = n-> n*n;
        System.out.println("Square of 5 is: "+f2.apply(5));
        System.out.println("Square of 10 is "+f2.apply(10));

    }
}
