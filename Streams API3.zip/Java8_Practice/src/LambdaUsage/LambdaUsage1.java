package LambdaUsage;

import functionalInterface.FunctionInterface1;

public class LambdaUsage1 {
    public static void main(String[] args) {
        FunctionInterface1 i = () -> System.out.println("Lambda expression implementation.");
        i.m1();
    }
}
