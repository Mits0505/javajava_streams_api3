package LambdaUsage;

import functionalInterface.FunctionInterface3;

public class BeforeLambda3 implements FunctionInterface3{
    @Override
    public int getLength(String s) {
        return s.length();
    }

    public static void main(String[] args) {
        FunctionInterface3 i = new BeforeLambda3();
        System.out.println("Length of Mitali is "+i.getLength("Mitali"));
        System.out.println("Length of Aggarwal is "+i.getLength("Aggarwal"));
    }
}
