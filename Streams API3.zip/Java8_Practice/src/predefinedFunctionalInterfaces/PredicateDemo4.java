package predefinedFunctionalInterfaces;

import java.util.Scanner;
import java.util.function.Predicate;

class User{
   private String userName;
   private String userPassword;

    public User(String userName, String userPassword) {
        this.userName = userName;
        this.userPassword = userPassword;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserPassword() {
        return userPassword;
    }
}
public class PredicateDemo4 {
    public static void main(String[] args) {
        Predicate<User> userValidation = user -> user.getUserName().equals("Mitali") && user.getUserPassword().equals("Mits");

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter User Name: ");
        String uName = scanner.next();

        System.out.print("Enter User Password: ");
        String uPassword = scanner.next();

        User user =new User(uName,uPassword);

        if(userValidation.test(user))
            System.out.println("Valid User");
        else
            System.out.println("Invalid User");

    }
}
