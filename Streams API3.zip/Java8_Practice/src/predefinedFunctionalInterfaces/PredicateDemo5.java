package predefinedFunctionalInterfaces;

import java.util.function.Predicate;

class SoftwareEngineer{
   private String name;
   private int age;
   private boolean havingGF;

    public SoftwareEngineer(String name, int age, boolean havingGF) {
        this.name = name;
        this.age = age;
        this.havingGF = havingGF;
    }

    @Override
    public String toString() {
        return name;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public boolean isHavingGF() {
        return havingGF;
    }
}

public class PredicateDemo5 {
    public static void main(String[] args) {
        Predicate<SoftwareEngineer> p = se -> se.getAge() >= 18 && se.isHavingGF() == true;

        SoftwareEngineer[] list={ new SoftwareEngineer("Durga",60,false),
                 new SoftwareEngineer("Sunil",25,true),
                 new SoftwareEngineer("Sayan",26,true),
                new SoftwareEngineer("Subbu",28,false),
                 new SoftwareEngineer("Ravi",17,true)};

        System.out.println("Software Engineers allowed in pub are: ");
        for(SoftwareEngineer se : list){
            if(p.test(se))
                System.out.println(se);
        }
    }
}
