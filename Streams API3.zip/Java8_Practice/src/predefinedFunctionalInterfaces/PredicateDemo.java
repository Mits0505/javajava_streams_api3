package predefinedFunctionalInterfaces;

import java.util.function.Predicate;

public class PredicateDemo {
    public static void main(String[] args) {
        Predicate<String> p = s->s.length() > 5;
        System.out.println("Length of \"abcdef\" is 5: "+p.test("abcdef"));
        System.out.println("Length of \"abc\" is 5: "+p.test("abc"));
    }
}
