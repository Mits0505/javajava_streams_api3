    package predefinedFunctionalInterfaces;

    import java.util.function.Predicate;

    public class PredicateDemo2 {
        public static void main(String[] args) {
           Predicate<String> startsWithK = s -> s.startsWith("K");

           String names[] = {"Sunny","Kajal","Mallika","Katrina","Kareena"};

           System.out.println("The name starts with K are: ");
            for (String name: names)
           {
               if(startsWithK.test(name))
                  System.out.println(name);
           }
        }
    }
