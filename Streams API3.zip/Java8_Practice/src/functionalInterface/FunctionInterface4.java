package functionalInterface;

public interface FunctionInterface4 {
    public int square(int n);
}