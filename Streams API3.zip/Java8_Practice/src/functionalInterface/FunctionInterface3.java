package functionalInterface;

public interface FunctionInterface3 {
    public int getLength(String s);
}