package dateAndTimeAPI;

import java.time.LocalDate;
import java.time.LocalTime;

public class DateAndTimeAPIDemo2 {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now();
        System.out.println("Date: "+localDate);

        int dd = localDate.getDayOfMonth();
        int mm = localDate.getMonthValue();
        int yyyy = localDate.getYear();
        System.out.println("Date in our own format: ");
        System.out.printf("Date: %d-%d-%d",dd,mm,yyyy);
        System.out.println();

        LocalTime localTime = LocalTime.now();
        System.out.println("Time: "+localTime);
        int h = localTime.getHour();
        int m = localTime.getMinute();
        int s = localTime.getSecond();
        int n = localTime.getNano();
        System.out.println("Time in our own format: ");
        System.out.printf("Time: %d:%d:%d:%d",h,m,s,n);
    }
}
