package dateAndTimeAPI;

import java.time.LocalDate;
import java.time.Period;

public class DateAndTimeAPIDemo5 {
    public static void main(String[] args) {
       LocalDate dateOfBirth = LocalDate.of(1990,05,31);
       LocalDate currentDate = LocalDate.now();
       Period period = Period.between(dateOfBirth,currentDate);
       System.out.printf("Your age is: %d year %d months and %d days",period.getYears(),period.getMonths(),period.getDays());
    }
}
