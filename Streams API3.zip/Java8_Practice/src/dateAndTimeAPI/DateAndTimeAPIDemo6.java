package dateAndTimeAPI;

import java.time.LocalDate;
import java.time.Period;
import java.time.Year;
import java.util.Scanner;

public class DateAndTimeAPIDemo6 {
    public static void main(String[] args) {
      System.out.println("Enter year: ");
      Scanner sc = new Scanner(System.in);
      int yyyy = sc.nextInt();
      Year year = Year.of(yyyy);
      if(year.isLeap())
          System.out.println(yyyy+" is leap year.");
      else
          System.out.println(yyyy+" is not a leap year.");
    }
}
