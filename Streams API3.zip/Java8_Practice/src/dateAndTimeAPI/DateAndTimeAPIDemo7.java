package dateAndTimeAPI;

import java.time.Year;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class DateAndTimeAPIDemo7 {
    public static void main(String[] args) {
        ZoneId zoneId = ZoneId.systemDefault(); // This tells system timezone.
        System.out.println("Your current system zone: "+zoneId);

        ZoneId usZone = ZoneId.of("America/Los_Angeles"); //This gives zone_id specific to given zone.
        ZonedDateTime zonedDateTime = ZonedDateTime.now(usZone);
        System.out.println("Us time currently: "+zonedDateTime);
    }
}
