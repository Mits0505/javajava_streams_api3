package dateAndTimeAPI;

import java.time.LocalDateTime;

public class DateAndTimeAPIDemo4 {
    public static void main(String[] args) {
        LocalDateTime localDateTime = LocalDateTime.of(1990,05,31,10,00);
        System.out.println("My Date of Birth: "+localDateTime);

        localDateTime = LocalDateTime.now();
        System.out.println("Date before 6 months: "+localDateTime.minusMonths(6));
        System.out.println("Date after 1 year: "+localDateTime.plusYears(1));
    }
}
