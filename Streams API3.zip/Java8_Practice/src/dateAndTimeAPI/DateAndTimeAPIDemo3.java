package dateAndTimeAPI;

import java.time.LocalDateTime;

public class DateAndTimeAPIDemo3 {
    public static void main(String[] args) {
        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println("Date: "+localDateTime);
        System.out.println();

        int dd = localDateTime.getDayOfMonth();
        int mm = localDateTime.getMonthValue();
        int yyyy = localDateTime.getYear();
        System.out.println("Date in our own format: ");
        System.out.printf("Date: %d-%d-%d",dd,mm,yyyy);
        System.out.println();

        int h = localDateTime.getHour();
        int m = localDateTime.getMinute();
        int s = localDateTime.getSecond();
        int n = localDateTime.getNano();
        System.out.println("Time in our own format: ");
        System.out.printf("Time: %d:%d:%d:%d",h,m,s,n);
    }
}
