package staticMethods;

interface StaticMainDemo {
    static void main(String[] args) {
        System.out.println("we can declare main method in an interface also.");
    }
}
