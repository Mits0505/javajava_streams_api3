package staticMethods;

interface Interf{
    static void m1() {
        System.out.println("Static Method of an Interface.");
    }
}

public class StaticDemo implements Interf {

    public static void main(String[] args) {
       // m1();
       // StaticDemo obj = new StaticDemo();
       // obj.m1();

       // StaticDemo.m1();

        Interf.m1();
    }
}

