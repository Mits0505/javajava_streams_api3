package BiFunctions;

import java.util.function.BiFunction;

class Employee{
    int eno;
    String name;
    double dailyWage;

    public Employee(int eno, String name, double dailyWage) {
        this.eno = eno;
        this.name = name;
        this.dailyWage = dailyWage;
    }
}

class TimeSheet{
    int eno;
    int days;

    public TimeSheet(int eno, int days) {
        this.eno = eno;
        this.days = days;
    }
}

public class EmployeeSalaryCalculation {
    public static void main(String[] args) {
        Employee e = new Employee(101, "Mitali",500);
        TimeSheet t = new TimeSheet(101,20);

        BiFunction<Employee,TimeSheet,Double> f = (emp,ts) -> emp.dailyWage*ts.days;

        System.out.println(e.name+" salary is "+f.apply(e,t));
    }
}
