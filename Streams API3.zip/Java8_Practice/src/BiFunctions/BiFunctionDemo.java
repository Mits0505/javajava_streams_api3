package BiFunctions;

import java.util.ArrayList;
import java.util.function.BiFunction;

class Student{
    String name;
    int rollNo;

    public Student(String name, int rollNo) {
        this.name = name;
        this.rollNo = rollNo;
    }
}
public class BiFunctionDemo {
    public static void main(String[] args) {
        ArrayList<Student> list = new ArrayList<>();
        BiFunction<String,Integer,Student> f = (name,rollNo) -> new Student(name,rollNo);

        list.add(f.apply("Mitali",101));
        list.add(f.apply("Lokesh",102));
        list.add(f.apply("Rajat",103));

        for(Student s: list){
            System.out.println("Student Name: "+s.name);
            System.out.println("Student RollNo: "+s.rollNo);
            System.out.println();
        }

    }
}
