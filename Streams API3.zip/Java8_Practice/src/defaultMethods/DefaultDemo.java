package defaultMethods;

interface Interf{
    default void m1() {
        System.out.println("Default Method.");
    }
}

public class DefaultDemo implements Interf{
    @Override
    public void m1() {
        System.out.println("Overriding version of the default method.");
    }

    public static void main(String[] args) {
        DefaultDemo obj = new DefaultDemo();
        obj.m1();
    }
}
