package anonymous;


class ThisInLambdaClass {
    int x = 777;
    public void m2() {
        Interf i = () -> {
            int x = 888;
            System.out.println(x); //888
            System.out.println(this.x); //777
        };
         i.m1();
    }
    public static void main(String[] args) {
        ThisInLambdaClass t = new ThisInLambdaClass();
        t.m2();
    }
 }
