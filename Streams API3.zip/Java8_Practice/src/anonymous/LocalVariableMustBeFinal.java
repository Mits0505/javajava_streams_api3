package anonymous;

public class LocalVariableMustBeFinal {
    int x = 777;
    public void m2() {
        int y =888;
        Interf i = () -> {
            int z = 999;
            //y=2;    // Local variables used in lambda must be final or effectively final.
            System.out.println(x); //777
            System.out.println(y); //888
            System.out.println(z); //999
        };
        i.m1();
    }
    public static void main(String[] args) {
        ThisInLambdaClass t = new ThisInLambdaClass();
        t.m2();
    }
}
