package consumer;

import java.util.function.Consumer;

class Movie1{
    String name;
    String result;

    public Movie1(String name, String result) {
        this.name = name;
        this.result = result;
    }
}
public class ConsumerDemo3 {
    public static void main(String[] args) {
        Consumer<Movie1> c1 = m->System.out.println("Movie "+m.name+" is ready to release");
        Consumer<Movie1> c2 = m->System.out.println("Movie "+m.name+" is just released and the result is: "+m.result);
        Consumer<Movie1> c3 = m->System.out.println("Movie "+m.name+" information storing in database.\n");

        Consumer<Movie1> chainedConsumer = c1.andThen(c2).andThen(c3);
        Movie1 m1= new Movie1("Bahubali","Hit");
        chainedConsumer.accept(m1);

        Movie1 m2= new Movie1("Spider","Flop");
        chainedConsumer.accept(m1);
    }
}
