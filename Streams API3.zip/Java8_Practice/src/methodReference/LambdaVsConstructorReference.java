package methodReference;

class Sample{
    Sample(){
        System.out.println("Sample Constructor.");
    }
}

interface Interface{
    Sample get();
}
public class LambdaVsConstructorReference {
    public static void main(String[] args) {
      /*  Interface i = () -> new Sample();   // Using Lambda
        i.get();*/

      Interface i = Sample::new;
      i.get();
    }
}
