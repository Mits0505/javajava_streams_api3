package methodReference;

interface Interf{
    void m1();
}
public class MethodReferenceDemo1 {

    static void m2(){
        System.out.println("Method Reference example");
    }
    public static void main(String[] args) {
        Interf i = MethodReferenceDemo1 :: m2;
        i.m1();
    }
}
