package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ArrayListSortingWithLambda {
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList();
        al.add(20);
        al.add(10);
        al.add(60);
        al.add(50);

        System.out.println("ArrayList Before Sorting: "+al);
        Collections.sort(al,(a,b)->(a>b)?-1:(a<b)?1:0);
        // Collections.sort(al,(a,b)->b.compareTo(a));
        Collections.sort(al, Comparator.reverseOrder());
        System.out.println("ArrayList after Sorting: "+al);

    }
}

