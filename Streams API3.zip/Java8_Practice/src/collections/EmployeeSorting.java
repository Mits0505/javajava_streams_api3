package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class EmployeeSorting {
    public static void main(String[] args) {
        ArrayList<Employee> al =new ArrayList<>();
        al.add(new Employee(1,"Mitali"));
        al.add(new Employee(4,"Lokesh"));
        al.add(new Employee(2,"Rajat"));
        al.add(new Employee(3,"Divya"));

        Collections.sort(al,(e1,e2)->e1.eno.compareTo(e2.eno));

        //Collections.sort(al, Comparator.comparing(e -> e.eno));

        System.out.println("List of Employees");
        System.out.println(al);
    }
}

class Employee{
    Integer eno;
    String ename;
    Employee(int eno, String ename){
      this.eno = eno;
      this.ename = ename;
    }

    public String toString(){
        return eno+": "+ename;
    }
}