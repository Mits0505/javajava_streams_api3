package supplier;

import java.util.Date;
import java.util.function.Supplier;

public class SupplierDemo2 {
    public static void main(String[] args) {
       Supplier<String> s = ()->{
           String names[] ={"Mitali","Lokesh","Rajat","Divya"};
           int i = (int)(Math.random()*4);
           return names[i];
       };
       System.out.println(s.get());
       System.out.println(s.get());
       System.out.println(s.get());
       System.out.println(s.get());
       System.out.println(s.get());
    }
}
