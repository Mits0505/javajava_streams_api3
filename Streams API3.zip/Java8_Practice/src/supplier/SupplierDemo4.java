package supplier;

import java.util.function.Predicate;
import java.util.function.Supplier;

public class SupplierDemo4 {
    public static void main(String[] args) {
     Supplier<String> s = () -> {
         String password = "";
         Supplier<Integer> d = () -> (int)(Math.random()*10);
         String symbols="ABCDEFGHIJKLMNOPQRSTUVWXYZ#$@";
         Supplier<Character> c = () -> symbols.charAt((int)(Math.random()*29));

         Predicate<Integer> p = i -> i%2==0;

         for(int i=0;i<6;i++){
             if(p.test(i))
                 password+=d.get();
             else
                 password+=c.get();
         }
         return  password;
     };

     System.out.println(s.get());
     System.out.println(s.get());
    }
}
