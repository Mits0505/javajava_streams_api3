package streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MapCollectionObjectsUsingStreams {
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<>();
        al.add(5);
        al.add(10);
        al.add(55);
        al.add(20);
        al.add(60);
        al.add(75);
        System.out.println("Complete List before filteration");
        System.out.println(al);

        System.out.println("Filtering collection object without stream");
        for (Integer i : al){
                System.out.print(2*i+" ");
        }
        System.out.println();

        System.out.println("Filtering collection object with stream");
        List<Integer> list = al.stream().map(i->i*2).collect(Collectors.toList());
        System.out.println(list);
    }
}
